from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from .models import Product

def index(request):
    print "Views/index"
    try:
        context = {'products':Product.objects.all()}
    except:
        context = dict()
    return render(request, 'products/index.html', context)

def new(request):
    print "views/new"
    return render(request, 'products/new.html')

def create(request):
    print 'views/create'

    if request.method == "POST":
        result = Product.objects.create(post=request.POST)
        print result[0]
        print result[1]

    return redirect(reverse('products:index'))

def edit(request, id):
    # edit_product = Product.objects.get(id=id)
    print 'views/edit'
    return render(request, 'products/edit.html')
